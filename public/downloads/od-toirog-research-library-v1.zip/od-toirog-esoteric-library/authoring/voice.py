from common import add, rows

WORDS = '''
Liminal|threshold|At a boundary or in a transition.|A liminal hour between the familiar and the untried.|essay;reading introduction|Follow with a concrete description of the actual transition.
Threshold|threshold|The point where one space or stage meets another.|Pause at the threshold; choose what you carry through.|onboarding;new beginning|Do not imply a sacred initiation has occurred.
Veil|threshold|A layer that partly conceals what lies beyond.|Let the veil stand for what you have not yet understood.|symbol guide;uncertainty|Do not claim to pierce another person's private mind.
Hinge|threshold|A small turning point with room for movement.|One honest question can become the hinge of a day.|daily reading|An ordinary word often carries more force than esoteric jargon.
Passage|threshold|Movement through a space or stage.|Give this passage a pace you can sustain.|transition reading|Avoid implying a fixed destination.
Crossing|threshold|A movement from one condition or place to another.|Every crossing asks what can travel with you.|transition;reflection|Use as metaphor unless literal travel is known.
Doorway|threshold|An opening into another space or possibility.|A doorway is an invitation, not an instruction.|onboarding;choice|Keep the actual interface action clear.
Vestibule|threshold|An entrance space before a larger interior.|Let this page be a vestibule for a slower question.|library introduction|Use sparingly; most buttons should use simpler language.
Interstice|threshold|A small intervening space or gap.|Notice the interstice between impulse and reply.|reflection prompt|Explain it through the example rather than stacking unfamiliar words.
Between|threshold|An unsettled or relational middle position.|You can be between chapters without being lost.|transition reading|Do not force closure where the user has not chosen it.
Nocturne|night|A composition or mood associated with night.|A nocturne for the thoughts the day left unfinished.|journal title|A literary title, not a named ancient rite.
Vesper|night|An evening-associated word with poetic and religious histories.|Vesper: a place to set down the day.|feature name|Do not claim a liturgical practice unless one is actually being described.
Crepuscular|night|Associated with twilight.|A crepuscular palette of blue, ash and muted gold.|design note|Better in editorial or design notes than everyday navigation.
Gloaming|night|The soft darkening around twilight.|In the gloaming, let one question remain simple.|reading introduction|Use one atmospheric phrase, then move to clear guidance.
Dusk|night|The fading light around the end of day.|Dusk gives the unfinished a gentler outline.|journal;closing copy|Do not claim night has greater predictive power.
Midnight|night|The middle of the conventional night.|Midnight is a mood here, not a deadline.|brand copy|Do not make access depend on a superstitious hour.
Afterglow|night|Light or feeling that remains after an event.|Keep the afterglow without asking the moment to return.|reflection;memory|Can acknowledge a positive experience without promising repetition.
Penumbra|night|Partial shadow; a useful image for incomplete clarity.|In the penumbra, distinguish what you see from what you suppose.|uncertainty reading|If used astronomically, apply the actual geometric definition.
Umbra|night|The deepest part of a shadow.|An umbra can shape an image without telling you its whole story.|visual system;essay|Do not label a person's identity as dark or contaminated.
Half-light|night|Light in which forms are visible but details remain uncertain.|In half-light, look twice before deciding.|uncertainty reading|Pair mystery with a practical action.
Luminous|light|Giving or appearing to give light.|Let one luminous detail hold your attention.|design;reading|Avoid promising a literal aura.
Glimmer|light|A small, faint light or sign of possibility.|Follow the glimmer far enough to ask a better question.|hope;beginning|A possibility is not a guarantee.
Ember|light|A small remaining source of heat after flame.|An ember can be tended without becoming a wildfire.|motivation;care|Do not equate intensity with relationship quality.
Radiance|light|An impression of light spreading outward.|Let radiance mean the warmth of a specific act.|appreciation|Keep metaphoric warmth separate from measured energy.
Halo|light|A ring of light or a symbolic luminous surround.|A narrow halo gives the image room to breathe.|art direction|Religious halos have specific histories; original UI rings need no sacred claim.
Lantern|light|A portable, bounded source of illumination.|Carry a lantern for the next step, not a map of every future.|guidance;brand copy|Do not imply comprehensive hidden knowledge.
Kindling|light|Material or conditions that help a fire begin.|Curiosity is kindling; a plan gives the spark somewhere to go.|creative reading|Avoid literal fire instructions in a digital reflection feature.
Lucent|light|Softly shining or clear in a poetic description.|A lucent line against an indigo field.|design vocabulary|Rare wording belongs in limited doses.
Iridescent|light|Showing shifting colors as the viewpoint changes.|An iridescent surface can remind us that viewpoint matters.|visual notes|No claim about an object's healing properties follows.
Scintilla|light|A tiny trace or spark.|A scintilla of interest is enough for a first question.|creative prompt|Explain through context; avoid a paragraph of rare words.
Orbit|sky|A curved path around a center; also an editorial image of relation.|Notice what your attention keeps in orbit.|brand;relationship|An orbital metaphor does not measure interpersonal attraction.
Constellation|sky|A named pattern of stars, or a metaphorical grouping.|A constellation of small choices shapes this week.|navigation;overview|Distinguish an artistic constellation from a real sky map.
Celestial|sky|Related to the sky or heavens.|A celestial palette with a grounded voice.|brand design|Do not imply a text was transmitted by a celestial being.
Sidereal|sky|Related to stars, with specific technical uses in astronomy and astrology.|Use sidereal only when the selected zodiac system calls for it.|technical glossary|Not a fancier synonym for every horoscope.
Syzygy|sky|An alignment of celestial bodies; a poetic image of unusual alignment.|Syzygy can title an essay about meeting at a shared angle.|essay title|Do not call every coincidence a real astronomical alignment.
Apogee|sky|An Earth-orbiting body's farthest orbital point from Earth.|As an explicit metaphor, an apogee can mark a distant perspective.|essay;cycle metaphor|Do not confuse it with any generic maximum in astronomical data.
Perigee|sky|An Earth-orbiting body's nearest orbital point to Earth.|As a metaphor, perigee can invite a question about closeness.|essay;relationship metaphor|Closeness in an orbit does not establish romantic compatibility.
Zenith|sky|The point overhead; metaphorically a high point.|A zenith deserves acknowledgment, not permanent residence.|achievement reflection|Do not claim the best period of someone's life has been calculated.
Nadir|sky|The point opposite the zenith; metaphorically a low point.|A nadir is a description of position, not a person's worth.|reflective essay|Use gently; do not forecast a user's lowest moment.
Firmament|sky|A poetic or historically cosmological name for the heavens.|Let the firmament remain spacious around a single clear question.|long-form atmosphere|It is not the terminology of modern orbital mechanics.
Ephemeral|time|Briefly present or short-lived.|An ephemeral feeling can still deserve attention.|daily reading|Do not infer a clinical course from a poetic description.
Interval|time|A space of time between events.|Leave an interval between feeling and decision.|daily practice|An ordinary pause needs no invented tradition.
Recurrence|time|Something returning or happening again.|A recurrence becomes useful when you notice what has changed.|pattern reflection|Do not assume repetition proves fate.
Cycle|time|A recurring sequence or circular pattern.|Name the cycle before trying to leave it.|review;habits|Specify whether the cycle is measured, observed or metaphorical.
Return|time|Coming back to a place, question or theme.|Return to the question with one new observation.|journal;navigation|Do not promise a person from the past will return.
Turning|time|A change of direction or stage.|The turning may begin with a smaller choice than you expect.|transition|A poetic turning is not a dated forecast.
Season|time|A period with a particular character.|Give this season a task it can actually hold.|longer reflection|Do not assume a user's geography or calendar from the word alone.
Echo|time|A repeated sound or a lingering resemblance.|An echo can be recognized without being obeyed.|memory;patterns|Do not infer a past life or paranormal message.
Vestige|time|A remaining trace of something earlier.|Which vestige still supports you, and which only occupies space?|release prompt|Avoid inventing a user's hidden history.
Continuum|time|An unbroken range or connected sequence.|Most choices live on a continuum, not at two extremes.|choice reflection|Use it to clarify, not to blur meaningful differences.
Oneiric|dream|Dreamlike in mood or imagery.|An oneiric landscape can hold a waking question.|art direction;essay|Do not call generated imagery a recovered dream memory.
Reverie|dream|A drifting, imaginative train of thought.|Let reverie propose; let reflection decide.|creative prompt|Imagination does not verify external events.
Phantasm|dream|An imagined or illusory form.|A phantasm can be vivid without being evidence.|symbol literacy|Do not tell a user their actual experience is unreal without context.
Mirage|dream|An apparent image that can mislead perception.|Ask what remains when the mirage of a perfect outcome fades.|expectation reflection|Avoid accusing the user of foolishness.
Imagery|dream|Images used to express or explore a meaning.|Let imagery make the question memorable and the action clear.|writing guide|Prefer this plain word when a technical mystical term adds nothing.
Chimera|dream|An imagined composite or difficult-to-realize idea.|A chimera may reveal a wish before it reveals a plan.|creative reflection|Do not present a mythic creature as zoological fact.
Refrain|dream|A repeated phrase or recurring element.|Notice the refrain in the story you tell yourself.|journal prompt|Do not treat repetition as a diagnosis.
Apparition|dream|An appearance, especially one described as ghostlike.|Use apparition for fiction or visual atmosphere with context.|fictional vignette|Do not claim a deceased person has appeared through the reading.
Enigma|mystery|Something puzzling that invites interpretation.|An enigma should open inquiry, not close it.|essay title|Never make essential product information deliberately mysterious.
Arcane|mystery|Known or understood by relatively few.|Translate the arcane term before asking it to carry meaning.|research library|Unfamiliar language does not prove depth.
Numinous|mystery|Evoking awe or a sense of the sacred.|Let numinous describe the atmosphere, not an established supernatural cause.|art direction;essay|Keep a felt quality distinct from proof.
Chthonic|mystery|Associated with the earth below or an underworld.|A chthonic palette can use stone, depth and muted warmth.|mythic art direction|Name any specific deity or tradition accurately.
Eldritch|mystery|Eerie or otherworldly in a literary register.|Reserve eldritch for fictional atmosphere, not personal forecasts.|fiction;optional dark theme|Too ominous for routine relationship guidance.
Hermetic silence|mystery|An original phrase suggesting enclosure and reserve.|Hermetic silence can title a fictional scene of withheld knowledge.|fictional vignette|This phrase does not designate a verified universal ritual.
Unseen|mystery|Outside the current view or awareness.|The unseen may simply be information you do not yet have.|uncertainty|Do not automatically turn missing information into a spiritual agent.
Hidden|mystery|Concealed or not yet noticed.|Look for a hidden assumption before a hidden enemy.|reflection|Avoid a fear-based secret-truth sales pitch.
Cipher|text|An encoded form or, metaphorically, something to interpret.|A cipher invites a key; a good reading provides context.|library;visual motif|Random glyphs are decoration, not an authentic ancient script.
Codex|text|A bound manuscript format; also a useful editorial title.|Od Toirog Codex: a working library of symbols and questions.|reference title|Do not present a new file as a rediscovered ancient book.
Palimpsest|text|A reused writing surface retaining traces of earlier writing.|A palimpsest offers an image for a story revised, not erased.|memory essay|Label psychological use as metaphor.
Folio|text|A leaf or page unit in a manuscript or book context.|Open a folio of the symbol archive.|reference navigation|Prefer page if the decorative word slows comprehension.
Marginalia|text|Notes written in the margins.|Make space for your own marginalia beside the reading.|journal feature|The user's interpretation can remain distinct from generated text.
Inscription|text|Words or marks set onto a surface.|Choose an inscription that names an intention in plain language.|personal note|Do not claim the words compel an outcome.
Glyph|text|A written or symbolic graphic form.|Every glyph should have either a known context or a clear original label.|icon system|Do not label invented marks as historical runes.
Illumination|text|Light, insight, or decorative manuscript work, depending on context.|An illumination can make one detail visible without explaining everything.|library;reading|Keep the intended sense clear.
Trace|text|A small remaining mark or indication.|Follow a trace only as far as the evidence allows.|research;reflection|Do not manufacture evidence through suggestive language.
Fragment|text|A surviving or partial piece.|A fragment can be meaningful without becoming the whole story.|short reading|Do not imply that an incomplete source supports a complete tradition.
Resonance|relation|A felt echo or meaningful similarity in this editorial use.|Notice what resonates, then ask why.|reading feedback|It is not a measured frequency of compatibility.
Accord|relation|A workable agreement or harmony.|Seek an accord that both people can describe.|relationship|Agreement must be mutual, not predicted on someone's behalf.
Confluence|relation|Different streams or influences meeting.|At a confluence, ask what each stream contributes.|relationship;life review|Do not erase important differences by celebrating unity.
Counterpoint|relation|Distinct lines or perspectives interacting without becoming identical.|Let difference become counterpoint rather than a contest.|relationship|A metaphor from music, not a compatibility algorithm.
Kinship|relation|Connection, affinity or familial relation depending on context.|Kinship can grow through repeated acts of recognition.|community|Do not assert ancestry or spiritual bloodlines.
Tension|relation|A pull between forces, needs or positions.|Name the tension before assigning blame.|relationship|A theme is not a verdict on either person's character.
Attunement|relation|Careful responsiveness to another's expressed state.|Attunement begins with listening, not knowing in advance.|relationship|Do not present it as telepathy.
Reciprocity|relation|Giving and receiving in a mutually responsive exchange.|Ask what reciprocity looks like in ordinary actions.|relationship|It need not mean identical contributions at every moment.
Reverence|relation|Careful respect for what is held significant.|Let reverence change how you attend to a place or person.|culture;reflection|Do not borrow a community's sacred status as a marketing effect.
Witness|relation|Attending to or acknowledging an experience.|Be a witness to the feeling before trying to solve it.|reflection|Do not impersonate a divine or ancestral witness.
Root|earth|A source of support or origin in this metaphor.|Return to a root you can actually nourish.|grounding prompt|Do not claim unseen ancestry or diagnose a root cause.
Stone|earth|A durable, weight-bearing material used here as a metaphor.|Choose a stone-simple action for a complicated day.|brand;practical prompt|No healing property is implied.
Vessel|earth|A container; metaphorically a form that holds experience.|Give the feeling a vessel: a sentence, a sketch, a conversation.|journal|Do not equate a person's body with an object for others to fill.
Seed|earth|A beginning with conditions still needed for growth.|A seed is a possibility, not a contract with the future.|beginning;project|Do not use as a covert pregnancy prediction.
Grove|earth|A small group of trees; also a community term in some traditions.|As an original metaphor, a grove can name a quiet collection.|collection title|Do not claim an actual Druid organization without context.
Ash|earth|A residue of burning, used here as an image of aftermath.|Ask what can be learned from the ash without relighting the fire.|closure essay|Avoid literal ritual-burning directions.
Tide|earth|A recurring rise and fall; metaphorically a changing level.|Notice the tide of attention and plan a sustainable pace.|daily reflection|If reporting a real tide, use real location and timing data.
Stillwater|earth|An original compound image for quiet water.|Stillwater can name a pause without promising perfect calm.|feature name|Clearly brand language, not an ancient doctrine.
Spiral|earth|A curve that turns while moving inward or outward.|A spiral returns near a point without returning unchanged.|growth metaphor|Do not claim all healing or history follows this shape.
Horizon|earth|The apparent boundary of sky and land, or a limit of view.|Choose a horizon broad enough for more than one outcome.|future reflection|A view ahead is not knowledge of the future.
'''

COPY = '''
Open the circle|onboarding|Begin with a question you can carry into the day.
A quieter view|onboarding|Make a little room around the question.
Your place in the pattern|onboarding|Explore a symbolic reading, then decide what belongs in your life.
Before the draw|tarot opening|Name what you are asking. Leave room for an answer that becomes a better question.
One card, one focus|tarot opening|Let one image hold your attention without asking it to explain everything.
A question with room|tarot opening|What can I understand, choose or discuss from here?
The next step|daily|You do not need the whole path to choose a considered next step.
Begin smaller|daily|Make the action small enough to be real today.
Attention returns|daily|Notice where your attention returns when the noise settles.
Useful uncertainty|daily|Leave one conclusion open until you have the information it needs.
Enough light|daily|Look for enough light to act carefully, not enough certainty to stop thinking.
A workable rhythm|daily|Choose a pace that leaves something of you for tomorrow.
Two perspectives|relationship|A shared story still needs room for two voices.
Ask before assuming|relationship|Let curiosity ask the question that fear has already answered.
A free answer|relationship|Offer honestly. Leave the other person free to answer honestly.
Different rhythms|relationship|Difference becomes clearer when each person names what they need.
Care in practice|relationship|What small action would make care easier to recognize?
Space and closeness|relationship|Closeness can grow where neither person has to disappear.
After disagreement|relationship|Begin with what happened, what it affected, and what would help repair it.
Reciprocal ground|relationship|Ask whether this connection makes room for both people's choices.
The unnamed feeling|journal|What feeling needs a sentence before it needs a solution?
Observation and story|journal|Write what you observed. Then write the story you added.
A changing belief|journal|Which belief has become too narrow for what you now know?
What remains|journal|What remains available without erasing what was lost?
An inherited rule|journal|Who taught you this rule, and do you still choose it?
The cost of holding|journal|What does holding on protect, and what does it prevent?
At the threshold|transition|Pause long enough to choose what travels with you.
A deliberate ending|transition|You can end a pattern without deciding the rest of your life today.
Room after an ending|transition|Let the space remain open before you rush to fill it.
Return with change|transition|You may meet the same question with a different answer.
The patient interval|pause|An interval can be part of the work.
Rest without a verdict|pause|A pause does not have to mean failure.
Unfinished is a condition|pause|Let unfinished describe the task, not your worth.
The closed book|closing|Keep what helps. Question what does not. The next choice remains yours.
Leave the circle open|closing|Carry one useful question back into ordinary life.
One thing to try|closing|Choose one action you can notice, not a promise you cannot test.
No question entered|interface|What would you like to reflect on?
No search results|interface|No entries match these filters. Try a broader word or clear a filter.
Source label|interface|Where this interpretation begins
Original interpretation label|interface|Od Toirog's interpretation
Unknown birth time|interface|Birth time is unknown. Time-sensitive chart features need a separate check.
Reading unavailable|interface|This reading could not be generated. Your saved notes are still here.
Optional return|interface|Return when another question is ready.
Browse symbols|call to action|Explore the symbol library
Start a reflection|call to action|Choose a question
Keep a note|call to action|Save your reflection
See the context|call to action|Read the source note
Close gently|call to action|Return to your day
'''

def build():
    for title, mood, meaning, example, good_for, note in rows(WORDS,6):
        add('vocabulary',title,meaning,'original Od Toirog voice','original_editorial',
            details=dict(mood=mood,working_meaning=meaning,original_example=example,
                         suitable_for=good_for.split(';'),usage_note=note,
                         attribution_note='Editorial word bank; not a claim that this word belongs to a secret tradition.'),
            tags='language;'+mood,use='editorial')
    for title, setting, copy in rows(COPY,3):
        add('copy',title,copy,'original Od Toirog voice','original_editorial',
            details=dict(placement=setting,text=copy),tags='copy;'+setting,use='editorial')
