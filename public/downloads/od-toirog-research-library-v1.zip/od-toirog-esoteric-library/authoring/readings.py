from common import add, rows

SPREADS = '''
Daily lantern|A brief daily reflection.|Notice:What deserves attention?;Practice:What small action could help?;Carry:What question can stay with me?|What can I approach more deliberately today?|Connect the action to the first card's theme; leave the final card as a question, not an outcome.
One clear question|A single-card pause.|Focus:What perspective can I examine?|What is within my choice in this situation?|Use one image, one interpretation and one concrete question.
Observation and assumption|Separating facts from interpretations.|Observed:What do I actually know?;Added:What story am I adding?;Check:What can I ask or verify?|What am I treating as fact before checking it?|Cards suggest questions about the user's account; they do not independently reveal the facts.
The threshold|Reflecting on a transition.|Behind:What is becoming less useful?;Threshold:What needs a decision?;Ahead:What small experiment is possible?|What do I want to carry into this next stage?|Do not call the last position a fixed future.
Shared orbit|A conversation between consenting partners.|My contribution:What am I bringing?;Your voice:What can I ask you to describe?;Shared need:What deserves joint attention?;Difference:Where might our needs differ?;Next agreement:What can we choose together?|What would make this connection more mutual?|The second position is a question for the partner, not a claim to read their mind.
Meeting with curiosity|Exploring a new connection.|Interest:What draws my attention?;Pace:What pace feels workable?;Boundary:What needs clarity?;Conversation:What could I ask openly?|How can I get to know this person without writing the ending first?|Distinguish attraction from evidence of reliability.
After a disagreement|Preparing a repair conversation.|Impact:What was affected?;Responsibility:What part can I own?;Need:What needs to be heard?;Repair:What request could be specific?|What would a fair repair involve?|Do not presume equal fault; use the user's actual account and allow uncertainty.
Closeness and space|Balancing connection and autonomy.|Closeness:What brings welcome connection?;Space:What protects individual needs?;Agreement:What boundary can be discussed?|What would make both closeness and space easier to choose?|Treat both needs as discussable without prescribing identical amounts.
Reciprocity check|Examining everyday give and take.|Give:What am I offering?;Receive:What do I welcome or resist?;Terms:What expectations need saying?;Adjust:What could become fairer?|What makes this exchange feel mutual?|Do not infer another person's motives from an unequal contribution.
Friendship in motion|Reflecting on a friendship.|Appreciate:What do I value?;Change:What has shifted?;Reach:What invitation could I make?|How can I meet this friendship as it is now?|Make room for changing circumstances without predicting abandonment.
Family patterns|Examining inherited expectations.|Inherited:What rule did I receive?;Useful:What still helps?;Outgrown:What needs questioning?;Chosen:What will I practice now?|Which inherited pattern do I still choose?|Do not invent ancestral trauma, curses or biological history.
Creative ember|Moving an idea toward a first attempt.|Spark:What attracts me?;Material:What do I have?;Friction:What limits the attempt?;First draft:What can I make?|How can I give this idea a small real form?|Let imagination propose a task that fits available resources.
The working table|Reviewing a project.|Purpose:What is the work for?;Method:What approach am I using?;Feedback:What should I inspect?;Next:What is the next useful change?|What would improve the work rather than only increase effort?|Use observable project facts where the user provides them.
Study and practice|Learning a skill.|Understand:What needs explanation?;Practice:What needs repetition?;Feedback:What would show improvement?|What is the smallest useful learning loop?|Do not predict examination or admission outcomes.
Resources and limits|Reflecting on practical capacity.|Available:What can I realistically use?;Committed:What is already promised?;Flexible:What can change?;Support:Where can I ask for help?|What fits my actual resources?|No investment, debt or income predictions; decisions require real figures.
The decision window|Comparing possible actions.|Aim:What matters most?;Option A:What question should I ask about A?;Option B:What question should I ask about B?;Missing:What information is needed?;Next:What reversible step can I take?|What would help me choose with clearer information?|Cards frame inquiry into options; they do not calculate which option will succeed.
Boundary and welcome|Defining a useful boundary.|Protect:What needs protection?;Welcome:What do I still want to allow?;Say:How can I express the boundary?|What does this boundary make possible?|Use clear language without treating all discomfort as danger.
Restoring attention|Considering rest and overload.|Drain:What draws heavily on attention?;Restore:What could support me?;Reduce:What demand can change?|What would make tomorrow more sustainable?|Avoid diagnosis and do not promise that reflection treats illness.
After an ending|Making room for closure.|Acknowledge:What ended?;Keep:What remains valuable?;Release:What can stop?;Support:What helps now?|How can I acknowledge this ending without deciding everything at once?|Do not require gratitude or a positive lesson from a loss.
Dream notebook|Using remembered dream images creatively.|Image:What detail stayed with me?;Association:What does it evoke for me?;Waking question:What can I reflect on now?|What do I personally associate with this image?|The dream and cards do not establish recovered memories or future events.
Weekly constellation|Reviewing a week without forecasting it.|Attention:What repeated?;Support:What helped?;Friction:What needs examination?;Learning:What changed my view?;Practice:What will I try next?|What did this week actually teach me?|Ask for actual events before claiming a pattern.
New-cycle intention|Beginning a chosen period of reflection.|Seed:What do I want to explore?;Conditions:What support is needed?;Commitment:What small action will I choose?|What can I begin without pretending to control the outcome?|This layout does not calculate a lunar phase or require a particular date.
Closing a cycle|Reviewing a chosen period.|Notice:What happened?;Value:What mattered?;Release:What can be left?;Carry:What is worth continuing?|What belongs in the next cycle?|The cycle can be a project or month; state which one is intended.
The two lenses|Keeping astrology and tarot distinct in one reflection.|Card image:What question does the card suggest?;Personal context:What does my actual situation add?;Action:What can I choose?|How do different symbolic lenses help me ask a clearer question?|If astrology is shown, retrieve computed chart facts separately; the card draw does not verify or generate them.
'''

METHODS = '''
Name the system first|Choose RWS for this release and store deck_system=rws with every draw.|Tarot content here cannot silently substitute for Marseille or Thoth meanings.
Fix the question before the draw|Record the chosen question and spread position labels before selecting cards.|This keeps the reading from retrofitting every result to a moving target.
Sample without replacement|Use a uniform shuffle of 78 unique card identifiers for a conventional single-deck spread.|Do not bias the draw toward dramatic or revenue-producing cards.
Make reversals optional|Record whether reversals are enabled and their chosen sampling policy.|A 50% orientation policy is an implementation choice, not an ancient requirement.
Keep the draw reproducible|Store the selected card IDs, orientations, spread version and content version.|A later text revision should not quietly rewrite which cards were drawn.
Separate image and interpretation|Retrieve the observed motif before the original editorial interpretation.|A symbol can suggest a question without establishing a hidden fact.
Read positions relationally|Explain how adjacent positions interact in the chosen question.|Avoid pasting three independent keyword paragraphs and calling them a synthesis.
Use one concrete image|Select one visible motif to anchor each short reading.|Too many symbols in a sentence make the prose decorative and hard to act on.
Name uncertainty precisely|Say whether something is unknown, a possibility, a feeling or a reported observation.|A vague supernatural explanation adds no reliable detail.
Personalize from supplied context|Use information the user actually provided and preserve their wording where useful.|Do not fabricate personal history, birth details or another person's emotions.
Court cards as approaches|Default to roles, behaviors or ways of responding rather than physical person descriptions.|Historical appearance and gender classifications are not used in this product.
Reversals as questions|Explore blockage, excess, inward expression or changing availability of a theme.|Do not multiply a compatibility score by a negative factor because a card is upside down.
Compatibility as a conversation|Offer topics such as communication, boundaries, care and pace.|No empirically calibrated relationship-success percentage is supplied by this library.
Daily reading as a prompt|Give one focus, one practical action and one reflective question.|Do not predict a specific event will happen today because a card appears.
Keep astronomy separate|Receive actual timestamps, coordinates and computed aspects from the calculation service.|This content database is not an ephemeris, transit calculator or sky observation.
Version editorial choices|Version card prose, spread positions, correspondence policies and translations independently.|You can reproduce an earlier reading even after changing the voice.
Preserve source scope|Use source_refs.scope to show which fields a source supports.|An authoritative historical source does not validate newly written predictions.
Let a session end|Offer a saved note, a closing line and an optional return.|Avoid streak penalties or warnings that another draw is needed to prevent harm.
'''

EXAMPLES = '''
Daily: a spark with a manageable load|Daily lantern|tarot-ace-of-wands;tarot-ten-of-wands;tarot-temperance|A new idea is competing with an already full task list.|The sprouting wand gives this reading a starting point: there is something you want to try. The bundle in the Ten of Wands asks whether it will simply become another obligation. Temperance offers a question of proportion. Could you give the idea twenty focused minutes by removing one less useful task? The theme here is a workable beginning. What would make this experiment small enough to enjoy and clear enough to learn from?
Relationship: closeness with space|Closeness and space|tarot-two-of-cups;tarot-the-hermit;tarot-justice|Both partners have agreed to talk about time together and time alone.|The Two of Cups offers an image of mutual attention. The Hermit's lantern gives space a useful purpose: time to think and return with something honest to say. Justice asks how the agreement can feel fair in practice. Rather than guessing how much closeness the other person wants, compare one concrete example of a good week. What amount of shared time and private time would each of you freely choose?
Choice: asking for missing information|Observation and assumption|tarot-the-moon;tarot-seven-of-cups;tarot-page-of-swords|A delayed reply has led the reader to imagine several explanations.|The Moon's uncertain light and the cloud-borne cups make a useful pair of images for incomplete information and the stories that rush to fill it. Neither card tells us why the reply is late. The Page of Swords suggests a better question: what could you check directly and respectfully? A simple message may give more information than another theory. What do you know from observation, and what are you adding?
Transition: acknowledging what ended|After an ending|tarot-death;tarot-six-of-cups;tarot-four-of-pentacles;tarot-six-of-swords|The reader has finished a long project and feels unsettled.|Death marks an ending in this editorial reading; the Six of Cups makes room for what remains valuable in memory. The tightly held pentacle asks which part of the old structure no longer needs protecting. The boat in the Six of Swords gives the final position a practical shape: a transition can happen with help and in stages. You do not need a replacement project immediately. What would help you close this one deliberately?
Work: practice with feedback|Study and practice|tarot-page-of-pentacles;tarot-eight-of-pentacles;tarot-three-of-pentacles|The reader is learning a new design tool.|The Page studies the object in front of them; the worker in the Eight repeats a craft; the Three places that work where others can respond to it. Together, these images suggest a simple learning loop: understand one feature, make a small example, then ask for specific feedback. The cards do not predict mastery. They give this session a useful structure. What could you make today that someone else could meaningfully review?
Reversal: a welcome that needs attention|One clear question|tarot-four-of-wands|The card is reversed; the reader is planning a gathering.|For this reading, the reversed Four of Wands asks about the conditions of welcome. Is there a practical detail that would make someone more comfortable or included? This is an editorial reversal lens, not a bad omen: Waite's historical reversed meaning for this card remained favorable. Check the invitation, timing or expectations. What would turn a planned celebration into a welcoming experience?
'''

def build():
    for title, purpose, positions, question, method in rows(SPREADS,5):
        pp=[]
        for index, part in enumerate(positions.split(';'),1):
            label,prompt=part.split(':',1)
            pp.append(dict(position=index,label=label,prompt=prompt))
        add('spread',title,purpose,'original Od Toirog practice','original_editorial',
            details=dict(card_count=len(pp),positions=pp,opening_question=question,synthesis_method=method,
                         origin='Newly authored layout for this collection; no claim of ancient provenance.'),
            tags='spread;reading',use='editorial')
    positions=[('Present influence','What is most active in the question?'),('Crossing influence','What complicates or challenges it?'),
        ('Aim','What am I trying to reach?'),('Foundation','What is already established?'),('Passing influence','What is receding?'),
        ('Emerging influence','What possibility is coming into view?'),('My stance','How am I approaching it?'),
        ('Environment','What circumstances or support matter?'),('Hopes and fears','What am I hoping or fearing?'),
        ('Possible trajectory','What direction is worth examining if current patterns continue?')]
    add('spread','Waite cross: modern reflection adaptation','Ten positions adapted from Waite’s published cross layout.','Rider–Waite–Smith',
        'historical_layout_with_original_adaptation','waite-cross',details=dict(card_count=10,
            positions=[dict(position=i,label=l,prompt=p) for i,(l,p) in enumerate(positions,1)],
            significator='Optional; not included in the ten cards. If used, record it separately and remove it before drawing.',
            opening_question='What influences and choices deserve examination here?',
            origin='Waite-era published layout. Ancient Celtic provenance is not established by the chapter title.',
            synthesis_method='Use the final position as a conditional reflective trajectory, not a guaranteed outcome.'),
        tags='spread;history;reading',use='editorial',scope='Position structure; question wording and non-predictive treatment are original adaptations.')
    for title, rule, reason in rows(METHODS,3):
        add('method',title,rule,'Od Toirog product design','original_editorial',
            details=dict(implementation_note=reason),tags='method;integration',use='editorial')
    for title, spread, cards, context, text in rows(EXAMPLES,5):
        add('example',title,text,'original Od Toirog voice','original_editorial',
            details=dict(spread_title=spread,card_ids=cards.split(';'),synthetic_context=context,text=text,
                orientation='Four of Wands reversed' if title.startswith('Reversal:') else 'all upright',
                provenance='Fictional demonstration; not a reading of a real person.'),
            tags='worked example;reading',use='editorial')
