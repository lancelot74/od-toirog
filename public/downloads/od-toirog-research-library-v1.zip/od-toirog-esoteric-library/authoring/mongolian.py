from common import add, rows

# Working Cyrillic localization candidates, not certified terminology.
DRAFTS = '''
Star|Од|Common sky word.|Suitable for ordinary interface copy after a native editorial pass.
Moon|Сар|Also means month in other contexts.|Use context to distinguish the celestial body from a calendar month.
Sun|Нар|Common sky word.|Keep astronomical data separate from symbolic interpretation.
Sky|Тэнгэр|Can carry religious meanings as well as the ordinary sky sense.|Do not silently turn poetic sky copy into a claim about a deity.
Orbit|Тойрог зам|Working phrase for an orbital path.|The brand Од Тойрог need not be treated as a technical translation.
Constellation|Одны орд|Candidate for a constellation.|Review alongside zodiac-sign terminology to prevent collisions.
Astrology|Зурхай|Broad term with local cultural contexts.|Specify the actual system: Western natal astrology, another tradition, or general horoscope copy.
Tarot|Таро / тарот|Two candidate transliterations for editorial selection.|Choose one spelling across the product; preserve the canonical English system ID.
Tarot reading|Тарогийн тайлал|Working phrase for a tarot interpretation.|Native editor should confirm spelling and preferred possessive form.
Daily reading|Өдрийн тайлал|Short interface candidate.|State whether this is a tarot reflection or an astrological reading.
Compatibility|Нийцэл|Candidate for interpersonal fit.|Does not itself imply a measured probability of relationship success.
Reflection|Эргэцүүлэл|Candidate for deliberate thought or reflection.|Useful for a journal feature; distinguish from reflection in a mirror.
Question|Асуулт|Plain interface label.|Prefer this over obscure ritual terminology for input fields.
Intention|Зорилго|Candidate emphasizing aim or purpose.|May differ from inward intention; review in sentence context.
Choice|Сонголт|Plain word for a choice.|Useful for preserving the reader's agency.
Possibility|Боломж|Candidate emphasizing an available opportunity or possibility.|Use a different phrase when expressing logical uncertainty if needed.
Uncertainty|Тодорхойгүй байдал|Candidate for a state of not knowing clearly.|Prefer explicit uncertainty over supernatural hints.
Beginning|Эхлэл|Plain word for a beginning.|Can title an original reflective theme.
Ending|Төгсгөл|Plain word for an ending.|Avoid turning this into a death forecast.
Transition|Шилжилт|Candidate for a change between states.|Review for warmth and naturalness in personal readings.
Threshold|Босго|Literal threshold with potential poetic use.|A brand metaphor does not confer a ritual initiation.
Boundary|Хил хязгаар|Candidate for a boundary or limit.|Review interpersonal phrasing so it feels natural rather than territorial.
Cycle|Мөчлөг|Candidate for a recurring sequence.|Specify whether measured, observed or metaphorical.
Balance|Тэнцвэр|Candidate for balance.|Do not imply equal contributions are always identical contributions.
Connection|Холбоо|Candidate for a connection or relation.|Review romantic contexts to avoid unintended technical meanings.
Trust|Итгэл|Candidate for trust, faith or confidence depending on context.|A card cannot establish whether another person deserves trust.
Care|Халамж|Candidate for interpersonal care.|Do not assign care work to one gender.
Patience|Тэвчээр|Candidate for patience or endurance.|Avoid language that asks someone to endure mistreatment.
Clarity|Тодорхой байдал|Candidate emphasizing being clear or definite.|For insight or lucidity, a native editor may prefer another phrase.
Mystery|Нууц|Candidate emphasizing a secret or unknown matter.|Review whether the desired tone is secret, wonder or unresolved question.
Symbol|Бэлгэдэл|Candidate for symbol or symbolism.|Useful in the educational library.
Source|Эх сурвалж|Plain source/reference label.|Suitable for making attribution visible.
Journal|Тэмдэглэл|Candidate for notes or journal content.|A full feature name may need a qualifier.
Draw a card|Хөзөр сонгох|Literal action candidate meaning choose a card.|If selection is random, explain the draw mechanism instead of implying deliberate choice.
Read the interpretation|Тайллыг унших|Working action label.|Review for natural product phrasing and consistent use of тайлал.
Return to your day|Өдөртөө эргэн ороорой|Poetic closing candidate.|Needs native stylistic review; do not publish unchanged solely because it is in this file.
The Fool: optional brand alias|Аянчин|A possible creative alias meaning traveler.|This is not a literal translation of The Fool. Keep canonical card ID tarot-the-fool and document any renaming.
'''

def build():
    for title,mn,meaning,note in rows(DRAFTS,4):
        entry=add('translation',title,mn,'Mongolian localization draft','language_draft',
            details=dict(english=title,mongolian_candidate=mn,meaning_note=meaning,editor_note=note,
                review_status='Native Mongolian editor required before publication',script='Cyrillic',
                scope='Original working translation candidate; no claim of traditional sacred terminology.'),
            tags='mongolian;translation;draft',use='review_required')
        entry['locale']='mn-draft'
