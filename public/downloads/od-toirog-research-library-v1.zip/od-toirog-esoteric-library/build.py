#!/usr/bin/env python3
"""Build the offline research collection with Python's standard library."""
import csv
import hashlib
import json
import re
import sqlite3
import sys
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'authoring'))
import sources,tarot,lexicon,context,voice,readings,mongolian
from common import ENTRIES,SOURCES

def dump(path,obj):
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def flatten(value):
    if isinstance(value,dict):return ' '.join(flatten(v) for v in value.values())
    if isinstance(value,list):return ' '.join(flatten(v) for v in value)
    return '' if value is None else str(value)

def main():
    ENTRIES.clear();SOURCES.clear()
    for module in (sources,tarot,lexicon,context,voice,readings,mongolian):module.build()
    data=ROOT/'data';data.mkdir(exist_ok=True)
    counts=Counter(e['category'] for e in ENTRIES)
    ids={e['id'] for e in ENTRIES};sids={s['id'] for s in SOURCES}
    assert len(ids)==len(ENTRIES),'Duplicate entry IDs'
    assert len(sids)==len(SOURCES),'Duplicate source IDs'
    assert all(r['source_id'] in sids for e in ENTRIES for r in e['source_refs']),'Broken source reference'
    assert all(s['url'].startswith('https://') for s in SOURCES)
    cards=[e for e in ENTRIES if e['category']=='tarot']
    assert len(cards)==78
    assert sorted(e['details']['number'] for e in cards if e['details']['arcana']=='major')==list(range(22))
    for suit in ['Wands','Cups','Swords','Pentacles']:
        assert sorted(e['details']['number'] for e in cards if e['details']['suit']==suit)==list(range(1,15))
    for e in ENTRIES:
        assert e['summary'] and e['details'] and e['traditions']
        if e['category']=='spread':
            assert len(e['details']['positions'])==e['details']['card_count']
            assert [p['position'] for p in e['details']['positions']]==list(range(1,e['details']['card_count']+1))
        if e['category']=='example':assert all(c in ids for c in e['details']['card_ids'])
        if e['locale']=='mn-draft':assert e['product_use']=='review_required'
        if e['evidence_status']=='original_editorial':assert not e['source_refs']
    meta=dict(title='Od Toirog Esoteric Research Library',version='1.0',researched_at='2026-09-19',
        entry_count=len(ENTRIES),counts=dict(counts),source_pages=len(SOURCES),
        grouped_source_works=len({s['independent_work_id'] for s in SOURCES}),
        scope='Western esotericism and RWS tarot, with limited comparative and Mongolian context; original editorial resources are separately labeled.',
        source_policy='Source citations support the scope recorded per reference, not supernatural efficacy or all original interpretations.',
        localization_status='37 working Mongolian candidates; native editorial review required',
        content_words=sum(len(re.findall(r'\S+',e['summary']+' '+flatten(e['details']))) for e in ENTRIES))
    dump(data/'metadata.json',meta)
    dump(data/'catalog.json',ENTRIES)
    (data/'catalog.jsonl').write_text(''.join(json.dumps(e,ensure_ascii=False)+'\n' for e in ENTRIES),encoding='utf-8')
    dump(data/'sources.json',SOURCES)
    for category in counts:dump(data/(category+'.json'),[e for e in ENTRIES if e['category']==category])
    with (data/'catalog.csv').open('w',encoding='utf-8-sig',newline='') as f:
        fields=['id','category','title','summary','traditions','evidence_status','product_use','locale','version','tags','details','source_refs','source_urls']
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        smap={s['id']:s for s in SOURCES}
        for e in ENTRIES:
            row=dict(e);row['source_urls']=[smap[r['source_id']]['url'] for r in e['source_refs']]
            w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in row.items()})
    with (data/'sources.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(SOURCES[0]));w.writeheader();w.writerows(SOURCES)
    build_schemas(data)
    build_sqlite(data)
    payload=dict(meta=meta,entries=ENTRIES,sources=SOURCES)
    packed=json.dumps(payload,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('\u2028','\\u2028').replace('\u2029','\\u2029')
    template=(ROOT/'authoring/browser-template.html').read_text(encoding='utf-8')
    assert template.count('__DATA__')==1
    (ROOT/'od-toirog-archive.html').write_text(template.replace('__DATA__',packed),encoding='utf-8')
    write_readme(meta)
    bibliography=['# Source register','',f"{len(SOURCES)} linked pages; {meta['grouped_source_works']} grouped works or reference articles.",'',
        'Dates below record research access. Relevant passages were reviewed; full works were not necessarily read cover to cover.',
        'Multiple chapters of Waite are one work. Primary texts document historical beliefs and practices, not proof that their claims work.','']
    for s in SOURCES:
        bibliography.extend([f"## {s['id']}",'',f"[{s['title']}]({s['url']}) — {s['author']}",'',
            f"Type: {s['kind']}. Accessed: {s['accessed']}. Review: {s['review_status']}.",'',
            'Supports: '+s['supports'],'','Limits: '+s['limitations'],''])
    (ROOT/'docs/sources.md').write_text('\n'.join(bibliography),encoding='utf-8')
    with sqlite3.connect(data/'knowledge.sqlite') as db:
        assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        assert not db.execute('PRAGMA foreign_key_check').fetchall()
        checks={q:db.execute('SELECT count(*) FROM entries_fts WHERE entries_fts MATCH ?',(q,)).fetchone()[0] for q in ['lantern','"Сар"','"reversed"']}
        assert all(checks.values()),checks
    validation=dict(data_integrity='passed',entry_ids_unique=True,source_references_resolve=True,
        tarot_count=78,major_sequence='0 through 21',minor_suits='Four suits, 14 ranks each',
        spread_positions_valid=True,example_card_references_valid=True,sqlite_integrity='ok',
        sqlite_foreign_keys='ok',fts_examples=checks,counts=dict(counts),
        source_access_note='Pages were reviewed during research; this build checks citation structure, not live external availability.')
    dump(data/'validation.json',validation)
    print(json.dumps(dict(meta=meta,validation=validation),ensure_ascii=False,indent=2))

def build_schemas(data):
    schema={'$schema':'https://json-schema.org/draft/2020-12/schema','$id':'urn:od-toirog:research-entry:1.0',
        'title':'Od Toirog research entry','type':'object','additionalProperties':False,
        'required':['id','category','title','summary','traditions','evidence_status','source_refs','details','tags','product_use','locale','version'],
        'properties':{k:{'type':'string','minLength':1} for k in ['id','category','title','summary','evidence_status','product_use','locale','version']}}
    schema['properties'].update(traditions={'type':'array','minItems':1,'items':{'type':'string'}},
        tags={'type':'array','items':{'type':'string'}},details={'type':'object'},
        source_refs={'type':'array','items':{'type':'object','required':['source_id','scope'],'additionalProperties':False,
            'properties':{'source_id':{'type':'string'},'scope':{'type':'string'}}}})
    schema['properties']['category']['enum']=sorted({e['category'] for e in ENTRIES})
    schema['properties']['product_use']['enum']=['educational','editorial','review_required']
    dump(data/'entry.schema.json',schema)
    dump(data/'source.schema.json',{'$schema':'https://json-schema.org/draft/2020-12/schema',
        '$id':'urn:od-toirog:research-source:1.0','title':'Research source','type':'object','additionalProperties':False,
        'required':list(SOURCES[0]),'properties':{k:({'type':'string','format':'uri'} if k=='url' else {'type':'string','minLength':1}) for k in SOURCES[0]}})

def build_sqlite(data):
    dbpath=data/'knowledge.sqlite'
    if dbpath.exists():dbpath.unlink()
    with sqlite3.connect(dbpath) as db:
        db.executescript('''
        PRAGMA foreign_keys=ON;
        CREATE TABLE entries(id TEXT PRIMARY KEY,category TEXT NOT NULL,title TEXT NOT NULL,
            summary TEXT NOT NULL,evidence_status TEXT NOT NULL,product_use TEXT NOT NULL,locale TEXT NOT NULL,payload_json TEXT NOT NULL);
        CREATE INDEX entries_category ON entries(category);
        CREATE TABLE sources(id TEXT PRIMARY KEY,title TEXT NOT NULL,author TEXT NOT NULL,url TEXT NOT NULL,
            kind TEXT NOT NULL,independent_work_id TEXT NOT NULL,payload_json TEXT NOT NULL);
        CREATE TABLE citations(entry_id TEXT NOT NULL REFERENCES entries(id),source_id TEXT NOT NULL REFERENCES sources(id),
            scope TEXT NOT NULL,PRIMARY KEY(entry_id,source_id));
        CREATE TABLE tags(entry_id TEXT NOT NULL REFERENCES entries(id),tag TEXT NOT NULL,PRIMARY KEY(entry_id,tag));
        CREATE VIRTUAL TABLE entries_fts USING fts5(id UNINDEXED,title,summary,body,tokenize='unicode61');
        ''')
        for s in SOURCES:db.execute('INSERT INTO sources VALUES(?,?,?,?,?,?,?)',(
            s['id'],s['title'],s['author'],s['url'],s['kind'],s['independent_work_id'],json.dumps(s,ensure_ascii=False)))
        for e in ENTRIES:
            db.execute('INSERT INTO entries VALUES(?,?,?,?,?,?,?,?)',tuple(e[k] for k in ['id','category','title','summary','evidence_status','product_use','locale'])+(json.dumps(e,ensure_ascii=False),))
            db.executemany('INSERT INTO citations VALUES(?,?,?)',[(e['id'],r['source_id'],r['scope']) for r in e['source_refs']])
            db.executemany('INSERT INTO tags VALUES(?,?)',[(e['id'],t) for t in set(e['tags'])])
            db.execute('INSERT INTO entries_fts VALUES(?,?,?,?)',(e['id'],e['title'],e['summary'],flatten(e['details'])+' '+flatten(e['traditions'])+' '+flatten(e['tags'])))

def write_readme(meta):
    labels={'tarot':'Complete RWS tarot card records','term':'Researched terms','vocabulary':'Atmospheric words with original examples',
        'tradition':'Tradition profiles','symbol':'Symbol and design notes','taboo':'Taboos, customs and claim checks','spread':'Reading layouts',
        'copy':'Original copy snippets','method':'Reading and integration methods','example':'Complete sample readings','translation':'Mongolian translation candidates'}
    lines=['# Od Toirog — Esoteric Research Library','',f"Version 1.0 · 19 September 2026 · **{meta['entry_count']} entries**",'',
        'Open **od-toirog-archive.html** in a browser for offline search, filters, entry details and source links. No server or API key is required. The source links themselves require an internet connection.','',
        'Start with **docs/research-report.md** for findings, voice direction and the proposed reading workflow. **docs/integration.md** explains the schema and import options.','',
        '## Contents','','| Collection | Records |','|---|---:|']
    lines += [f"| {labels[k]} | {v} |" for k,v in meta['counts'].items()]
    lines += ['',f"The reference register contains **{meta['source_pages']} linked pages grouped into {meta['grouped_source_works']} works or reference articles**. Multiple Waite chapters are one work. These counts do not imply that all books were read in full or that every page is an independent authority.",'',
        '## Importable formats','','- `data/catalog.json` — all records as an array.',
        '- `data/catalog.jsonl` — one complete record per line.',
        '- `data/catalog.csv` — spreadsheet-friendly export; structured cells contain JSON.',
        '- `data/knowledge.sqlite` — entries, sources, citations, tags and full-text search.',
        '- `data/sources.json` and `data/sources.csv` — attribution and review scopes.',
        '- Category-specific JSON files — convenient subsets of the same records.',
        '- `data/entry.schema.json`, `data/source.schema.json`, `data/metadata.json`, `data/validation.json` — structure, counts and checks.','',
        '## Use and scope','',
        'The first edition emphasizes Western esotericism and RWS tarot. It also includes limited comparative context and a specifically sourced Mongolian sacred-landscape reference. It is not an exhaustive global encyclopedia.',
        '',
        'Historical descriptions and beliefs are separated from original editorial interpretations. Source links support only the scope stated in each citation. Original spreads, copy and reading examples were newly authored for this collection. The 37 Mongolian entries are drafts requiring native review.',
        '',
        'No source books, modern deck artwork or user birth records are included. External sources and any artwork selected later have their own terms. This is a research and writing database, not a trained model, an ephemeris or a validated prediction system.','',
        '## Rebuild and search','','Requires Python 3.9+ with SQLite FTS5 enabled; no third-party Python packages.','',
        '```bash','python3 build.py','python3 examples/search.py lantern','python3 examples/search.py --category tarot relationship',
        'python3 examples/search.py --category translation Сар --json','```','',
        'The authoring modules under `authoring/` are the editable inputs. Rebuilding overwrites generated exports. The browser is generated from the same catalog to prevent content drift.','',
        'Validation covers record uniqueness, citation integrity, 78-card coverage, suit and rank coverage, spread positions, example references, SQLite integrity and multilingual full-text retrieval. See `docs/validation.md` for browser checks and the remaining review boundaries.','']
    (ROOT/'README.md').write_text('\n'.join(lines),encoding='utf-8')

if __name__=='__main__':main()
