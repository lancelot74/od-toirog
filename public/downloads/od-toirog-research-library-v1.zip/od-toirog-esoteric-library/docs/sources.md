# Source register

117 linked pages; 33 grouped works or reference articles.

Dates below record research access. Relevant passages were reviewed; full works were not necessarily read cover to cover.
Multiple chapters of Waite are one work. Primary texts document historical beliefs and practices, not proof that their claims work.

## sep-mysticism

[Mysticism](https://plato.stanford.edu/entries/mysticism/) — Stanford Encyclopedia of Philosophy

Type: scholarly_reference. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Mysticism, experience, interpretation, ineffability and noetic claims.

Limits: Selected sections reviewed; definitions vary across traditions.

## sep-dionysius

[Pseudo-Dionysius the Areopagite](https://plato.stanford.edu/entries/pseudo-dionysius-areopagite/) — Stanford Encyclopedia of Philosophy

Type: scholarly_reference. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Apophatic and kataphatic theology; divine names and limits of language.

Limits: Christian theological context; not a generic occult dictionary.

## sep-ibn-arabi

[Ibn Arabi](https://plato.stanford.edu/entries/ibn-arabi/) — Stanford Encyclopedia of Philosophy

Type: scholarly_reference. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Imaginal reality, imagination and barzakh in Ibn Arabi.

Limits: Selected philosophical sections reviewed; does not represent every Sufi school.

## sep-plotinus

[Plotinus](https://plato.stanford.edu/entries/plotinus/) — Stanford Encyclopedia of Philosophy

Type: scholarly_reference. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: The One, Intellect and metaphysical procession.

Limits: Selected sections reviewed; philosophical claims described, not endorsed as measurements.

## sep-proclus

[Proclus](https://plato.stanford.edu/entries/proclus/) — Stanford Encyclopedia of Philosophy

Type: scholarly_reference. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Theurgy and late Platonist approaches to divine assimilation.

Limits: Section 3.6 reviewed.

## sep-ficino

[Marsilio Ficino](https://plato.stanford.edu/entries/ficino/) — Stanford Encyclopedia of Philosophy

Type: scholarly_reference. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Renaissance Platonism and reception of ancient theology.

Limits: Overview reviewed; no claims of uninterrupted ancient lineage.

## iep-gnostic

[Gnosticism](https://iep.utm.edu/gnostic/) — Internet Encyclopedia of Philosophy

Type: scholarly_reference. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Gnosis, aeons, Sophia, pleroma and demiurge in selected systems.

Limits: An interpretive overview of diverse movements, not a uniform creed.

## unesco-burkhan

[Great Burkhan Khaldun Mountain and its surrounding sacred landscape](https://whc.unesco.org/en/list/1440/) — UNESCO World Heritage Centre

Type: institutional_heritage. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Sacred landscape, worship traditions, ovoo and documented restrictions.

Limits: Nomination-era heritage description; not a current visitor-permission or legal guide.

## ashmolean-spellbound

[Spellbound: Magic, Ritual & Witchcraft](https://www.ashmolean.org/spellbound) — Ashmolean Museum, University of Oxford

Type: museum_reference. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Material objects and historical European magical beliefs.

Limits: Exhibition ran in 2018–2019; supports object history, not supernatural efficacy.

## cornell-witchcraft

[The World Bewitch'd: Introduction](https://rmc.library.cornell.edu/witchcraft/exhibition/introduction/index.html) — Cornell University Library

Type: curated_archive. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Witchcraft accusations, persecution and historical evidence.

Limits: Accusations are not proof that the accused practiced magic.

## agrippa-1

[Three Books of Occult Philosophy, Book I, part 1](https://www.esotericarchives.com/agrippa/agrippa1.htm) — Heinrich Cornelius Agrippa; English translation 1651; digital edition Joseph H. Peterson

Type: historical_primary. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Natural magic, elements and hidden properties in Renaissance cosmology.

Limits: Historical text; modern editorial notes and transcriptions have separate rights.

## agrippa-2

[Three Books of Occult Philosophy, Book II, part 1](https://www.esotericarchives.com/agrippa/agrippa2.htm) — Heinrich Cornelius Agrippa; English translation 1651; digital edition Joseph H. Peterson

Type: historical_primary. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Number symbolism and mathematical magic.

Limits: A historical belief system; numerology is not statistical inference.

## agrippa-2b

[Three Books of Occult Philosophy, Book II, part 2](https://www.esotericarchives.com/agrippa/agripp2b.htm) — Heinrich Cornelius Agrippa; English translation 1651; digital edition Joseph H. Peterson

Type: historical_primary. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Numerical correspondences, letters and celestial symbolism.

Limits: Selected passages reviewed; do not treat correspondences as universal.

## agrippa-3

[Three Books of Occult Philosophy, Book III, part 1](https://www.esotericarchives.com/agrippa/agrippa3.htm) — Heinrich Cornelius Agrippa; English translation 1651; digital edition Joseph H. Peterson

Type: historical_primary. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Religious magic, secrecy and restrictions on disclosure.

Limits: Chapter II especially; author's reports about other cultures require independent verification.

## goetia

[Lemegeton, Part 1: Goetia](https://www.esotericarchives.com/solomon/goetia.htm) — Historical manuscripts; digital edition Joseph H. Peterson

Type: historical_primary. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Spirit catalogues, seals, circles, conjuration and dismissal.

Limits: Literary and historical reference; no claim that spirits or coercive rites work.

## emerald

[Emerald Tablet of Hermes: Translations](https://sacred-texts.com/alc/emerald.htm) — Historical translations collected by Internet Sacred Text Archive

Type: primary_text_collection. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Upper/lower correspondence and alchemical imagery.

Limits: Composite page includes modern translations and commentary; no bulk text copied.

## hydrolith

[The Sophic Hydrolith, in The Hermetic Museum, Volume I](https://sacred-texts.com/book/the-hermetic-museum-volume-i/shell/the-sophic-hydrolith) — Historical alchemical tract; A. E. Waite English edition, 1893

Type: historical_primary. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Black, white and red stages; dissolution, condensation and allegory.

Limits: Historical chemical and religious claims are not instructions or verified remedies.

## golden-tract

[The Golden Tract Concerning the Stone of the Philosophers](https://sacred-texts.com/book/the-hermetic-museum-volume-i/shell/the-golden-tract-concerning-the-stone-of-the-philosophers) — Historical alchemical tract; A. E. Waite English edition, 1893

Type: historical_primary. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Philosophers' stone, concealment, allegory and claims to secret knowledge.

Limits: Historical rhetoric is evidence of what authors claimed, not proof of transmutation.

## kybalion

[The Kybalion, Chapter II: The Seven Hermetic Principles](https://sacred-texts.com/book/the-kybalion/shell/chapter-ii-the-seven-hermetic-principles) — Three Initiates, 1908

Type: historical_primary. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Mentalism, correspondence, vibration, polarity, rhythm, cause/effect and gender.

Limits: Modern occult publication; not evidence of an ancient Egyptian seven-law syllabus.

## oto-thelema

[Thelema](https://oto-usa.org/thelema/) — Ordo Templi Orientis, U.S. Grand Lodge

Type: practitioner_self_description. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Thelema, Crowley, individual Will and Magick.

Limits: Represents the organization’s own introductory account.

## obod-druidry

[What Is Druidry?](https://druidry.org/druid-way/what-druidry) — Order of Bards, Ovates & Druids

Type: practitioner_self_description. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Contemporary Druidry, creativity, nature and wisdom.

Limits: Represents this order; does not establish all ancient Druid practices.

## harvard-wicca

[Wicca](https://pluralism.org/wicca) — Harvard University, The Pluralism Project

Type: institutional_reference. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Wicca as a stream of contemporary Paganism.

Limits: Short overview; insufficient for universal rules about Wiccan practice.

## wiki-tarot

[Tarot](https://en.wikipedia.org/wiki/Tarot) — Wikipedia contributors

Type: secondary_orientation. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Italian playing-card history and later occult use.

Limits: Orientation only; historical dates should receive specialist checking before a scholarly publication.

## wiki-rws

[Rider–Waite Tarot](https://en.wikipedia.org/wiki/Rider%E2%80%93Waite_Tarot) — Wikipedia contributors

Type: secondary_orientation. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: A. E. Waite, Pamela Colman Smith and the 1909 deck.

Limits: Use alongside Waite's primary text; modern editions may differ.

## wiki-marseille

[Tarot of Marseilles](https://en.wikipedia.org/wiki/Tarot_of_Marseilles) — Wikipedia contributors

Type: secondary_orientation. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Marseille deck family, pip structure and ordering.

Limits: A family of decks, not one canonical edition.

## wiki-thoth

[Thoth Tarot](https://en.wikipedia.org/wiki/Thoth_tarot_deck) — Wikipedia contributors

Type: secondary_orientation. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Crowley/Harris deck, renamed trumps and courts.

Limits: Comparison only; not a production-ready astrological correspondence table.

## wiki-golden-dawn

[Hermetic Order of the Golden Dawn](https://en.wikipedia.org/wiki/Hermetic_Order_of_the_Golden_Dawn) — Wikipedia contributors

Type: secondary_orientation. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Modern initiatory order and occult synthesis.

Limits: High-level orientation; internal teachings differ across later organizations.

## wiki-kabbalah

[Kabbalah](https://en.wikipedia.org/wiki/Kabbalah) — Wikipedia contributors

Type: secondary_orientation. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Jewish Kabbalah, sefirot and distinction from later adaptations.

Limits: Educational draft; consult Jewish scholarship before publishing detailed teachings.

## wiki-tapu

[Tapu in Polynesian cultures](https://en.wikipedia.org/wiki/Tapu_(Polynesian_culture)) — Wikipedia contributors

Type: secondary_orientation. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Sacred restrictions and the background of the English word taboo.

Limits: Local meanings differ; community-specific review needed.

## waite-index

[The Pictorial Key to the Tarot](https://sacred-texts.com/tarot/pkt/index.htm) — A. E. Waite, 1910/1911 editions; designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Structure of this tarot reference and chapter navigation.

Limits: The 78 card pages below belong to this same work, not 78 independent authorities.

## waite-history

[The Pictorial Key: The Tarot in History](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/section-4-the-tarot-in-history) — A. E. Waite

Type: historical_primary. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Waite's own critique of speculative tarot origin stories.

Limits: Historical scholarship has developed since Waite; not the final authority on origins.

## waite-divination

[The Pictorial Key: Greater Arcana Divinatory Meanings](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/section-3-the-greater-arcana-and-their-divinatory-meanings) — A. E. Waite

Type: historical_primary. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Historical predictive meanings, including alarming and gendered formulations.

Limits: Preserved as context; Od Toirog interpretations deliberately do not reproduce those judgments.

## waite-cross

[The Pictorial Key: An Ancient Celtic Method of Divination](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/section-7-an-ancient-celtic-method-of-divination) — A. E. Waite

Type: historical_primary. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Ten-card cross spread and optional significator.

Limits: The word ancient in the chapter title is an authorial claim, not established Celtic provenance.

## wiki-chaos

[Chaos magic](https://en.wikipedia.org/wiki/Chaos_magic) — Wikipedia contributors

Type: secondary_orientation. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Modern sigil practice, instrumental belief and the specialized use of gnosis.

Limits: Orientation only; references to physics within occult systems do not validate the systems scientifically.

## wiki-egregore

[Egregore](https://en.wikipedia.org/wiki/Egregore) — Wikipedia contributors

Type: secondary_orientation. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Modern group thought-form concept and earlier different uses.

Limits: No claim that a collective entity has been observed.

## wiki-theosophy

[Theosophy](https://en.wikipedia.org/wiki/Theosophy) — Wikipedia contributors

Type: secondary_orientation. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Modern Theosophy and its esoteric cosmology.

Limits: Distinguish modern appropriations from the religions they reference.

## wiki-akashic

[Akashic records](https://en.wikipedia.org/wiki/Akashic_records) — Wikipedia contributors

Type: secondary_orientation. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Theosophical belief in an immaterial record.

Limits: Not a searchable empirical archive or verified account of a user's past lives.

## wiki-sigil

[Sigil](https://en.wikipedia.org/wiki/Sigil) — Wikipedia contributors

Type: secondary_orientation. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Historical seals and modern intention-symbol practices.

Limits: The meaning depends on the named system.

## wiki-divination

[Divination](https://en.wikipedia.org/wiki/Divination) — Wikipedia contributors

Type: secondary_orientation. Accessed: 2026-09-19. Review: selected_relevant_passages_reviewed.

Supports: Broad term and differences among divinatory media.

Limits: Brief terminology orientation; no efficacy conclusion follows from historical use.

## waite-magician

[The Pictorial Key: Magician](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/i-the-magician) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-high-priestess

[The Pictorial Key: High Priestess](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/ii-the-high-priestess) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-empress

[The Pictorial Key: Empress](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/iii-the-empress) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-emperor

[The Pictorial Key: Emperor](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/iv-the-emperor) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-hierophant

[The Pictorial Key: Hierophant](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/v-the-hierophant) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-lovers

[The Pictorial Key: Lovers](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/vi-the-lovers) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-chariot

[The Pictorial Key: Chariot](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/vii-the-chariot) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-strength

[The Pictorial Key: Strength](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/viii-strength-or-fortitude) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-hermit

[The Pictorial Key: Hermit](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/ix-the-hermit) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-wheel-of-fortune

[The Pictorial Key: Wheel of Fortune](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/x-wheel-of-fortune) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-justice

[The Pictorial Key: Justice](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/xi-justice) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-hanged-man

[The Pictorial Key: Hanged Man](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/xii-the-hanged-man) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-death

[The Pictorial Key: Death](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/xiii-death) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-temperance

[The Pictorial Key: Temperance](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/xiv-temperance) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-devil

[The Pictorial Key: Devil](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/xv-the-devil) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-tower

[The Pictorial Key: Tower](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/xvi-the-tower) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-star

[The Pictorial Key: Star](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/xvii-the-star) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-moon

[The Pictorial Key: Moon](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/xviii-the-moon) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-sun

[The Pictorial Key: Sun](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/xix-the-sun) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-judgement

[The Pictorial Key: Judgement](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/xx-the-last-judgement) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-fool

[The Pictorial Key: Fool](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/zero-the-fool) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-world

[The Pictorial Key: World](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/xxi-the-world) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-king-of-wands

[The Pictorial Key: King of Wands](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/king-of-wands) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-queen-of-wands

[The Pictorial Key: Queen of Wands](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/queen-of-wands) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-knight-of-wands

[The Pictorial Key: Knight of Wands](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/knight-of-wands) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-page-of-wands

[The Pictorial Key: Page of Wands](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/page-of-wands) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-ten-of-wands

[The Pictorial Key: Ten of Wands](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/ten-of-wands) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-nine-of-wands

[The Pictorial Key: Nine of Wands](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/nine-of-wands) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-eight-of-wands

[The Pictorial Key: Eight of Wands](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/eight-of-wands) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-seven-of-wands

[The Pictorial Key: Seven of Wands](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/seven-of-wands) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-six-of-wands

[The Pictorial Key: Six of Wands](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/six-of-wands) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-five-of-wands

[The Pictorial Key: Five of Wands](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/five-of-wands) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-four-of-wands

[The Pictorial Key: Four of Wands](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/four-of-wands) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-three-of-wands

[The Pictorial Key: Three of Wands](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/three-of-wands) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-two-of-wands

[The Pictorial Key: Two of Wands](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/two-of-wands) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-ace-of-wands

[The Pictorial Key: Ace of Wands](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/ace-of-wands) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-king-of-cups

[The Pictorial Key: King of Cups](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/king-of-cups) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-queen-of-cups

[The Pictorial Key: Queen of Cups](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/queen-of-cups) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-knight-of-cups

[The Pictorial Key: Knight of Cups](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/knight-of-cups) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-page-of-cups

[The Pictorial Key: Page of Cups](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/page-of-cups) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-ten-of-cups

[The Pictorial Key: Ten of Cups](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/ten-of-cups) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-nine-of-cups

[The Pictorial Key: Nine of Cups](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/nine-of-cups) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-eight-of-cups

[The Pictorial Key: Eight of Cups](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/eight-of-cups) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-seven-of-cups

[The Pictorial Key: Seven of Cups](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/seven-of-cups) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-six-of-cups

[The Pictorial Key: Six of Cups](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/six-of-cups) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-five-of-cups

[The Pictorial Key: Five of Cups](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/five-of-cups) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-four-of-cups

[The Pictorial Key: Four of Cups](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/four-of-cups) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-three-of-cups

[The Pictorial Key: Three of Cups](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/three-of-cups) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-two-of-cups

[The Pictorial Key: Two of Cups](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/two-of-cups) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-ace-of-cups

[The Pictorial Key: Ace of Cups](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/ace-of-cups) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-king-of-swords

[The Pictorial Key: King of Swords](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/king-of-swords) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-queen-of-swords

[The Pictorial Key: Queen of Swords](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/queen-of-swords) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-knight-of-swords

[The Pictorial Key: Knight of Swords](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/knight-of-swords) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-page-of-swords

[The Pictorial Key: Page of Swords](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/page-of-swords) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-ten-of-swords

[The Pictorial Key: Ten of Swords](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/ten-of-swords) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-nine-of-swords

[The Pictorial Key: Nine of Swords](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/nine-of-swords) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-eight-of-swords

[The Pictorial Key: Eight of Swords](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/eight-of-swords) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-seven-of-swords

[The Pictorial Key: Seven of Swords](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/seven-of-swords) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-six-of-swords

[The Pictorial Key: Six of Swords](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/six-of-swords) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-five-of-swords

[The Pictorial Key: Five of Swords](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/five-of-swords) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-four-of-swords

[The Pictorial Key: Four of Swords](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/four-of-swords) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-three-of-swords

[The Pictorial Key: Three of Swords](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/three-of-swords) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-two-of-swords

[The Pictorial Key: Two of Swords](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/two-of-swords) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-ace-of-swords

[The Pictorial Key: Ace of Swords](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/ace-of-swords) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-king-of-pentacles

[The Pictorial Key: King of Pentacles](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/king-of-pentacles) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-queen-of-pentacles

[The Pictorial Key: Queen of Pentacles](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/queen-of-pentacles) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-knight-of-pentacles

[The Pictorial Key: Knight of Pentacles](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/knight-of-pentacles) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-page-of-pentacles

[The Pictorial Key: Page of Pentacles](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/page-of-pentacles) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-ten-of-pentacles

[The Pictorial Key: Ten of Pentacles](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/ten-of-pentacles) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-nine-of-pentacles

[The Pictorial Key: Nine of Pentacles](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/nine-of-pentacles) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-eight-of-pentacles

[The Pictorial Key: Eight of Pentacles](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/eight-of-pentacles) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-seven-of-pentacles

[The Pictorial Key: Seven of Pentacles](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/seven-of-pentacles) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-six-of-pentacles

[The Pictorial Key: Six of Pentacles](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/six-of-pentacles) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-five-of-pentacles

[The Pictorial Key: Five of Pentacles](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/five-of-pentacles) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-four-of-pentacles

[The Pictorial Key: Four of Pentacles](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/four-of-pentacles) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-three-of-pentacles

[The Pictorial Key: Three of Pentacles](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/three-of-pentacles) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-two-of-pentacles

[The Pictorial Key: Two of Pentacles](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/two-of-pentacles) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.

## waite-ace-of-pentacles

[The Pictorial Key: Ace of Pentacles](https://sacred-texts.com/book/the-pictorial-key-to-the-tarot/shell/ace-of-pentacles) — A. E. Waite; card designs by Pamela Colman Smith

Type: historical_primary. Accessed: 2026-09-19. Review: card_passage_reviewed.

Supports: Card imagery and brief historical notes only; daily, relationship and reversed interpretations in this database are original editorial writing.

Limits: One historical interpretation, not a universal meaning or verified prediction.
