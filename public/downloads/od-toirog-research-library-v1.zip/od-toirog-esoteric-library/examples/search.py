#!/usr/bin/env python3
"""Search the local research database. No network or dependencies."""
import argparse
import json
import sqlite3
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('words',nargs='*')
p.add_argument('--category')
p.add_argument('--limit',type=int,default=10)
p.add_argument('--json',action='store_true')
args=p.parse_args()
if not 1<=args.limit<=500:p.error('--limit must be between 1 and 500')
dbfile=Path(__file__).resolve().parents[1]/'data/knowledge.sqlite'
params=[]
if args.words:
    phrase=' AND '.join('"'+word.replace('"','""')+'"' for word in args.words if word.strip())
    sql='SELECT e.payload_json FROM entries_fts f JOIN entries e ON e.id=f.id WHERE entries_fts MATCH ?'
    params.append(phrase)
    order=' ORDER BY bm25(entries_fts)'
else:
    sql='SELECT e.payload_json FROM entries e WHERE 1=1'
    order=' ORDER BY e.title'
if args.category:sql+=' AND e.category=?';params.append(args.category)
sql+=order+' LIMIT ?';params.append(args.limit)
with sqlite3.connect(f'file:{dbfile}?mode=ro',uri=True) as db:
    entries=[json.loads(row[0]) for row in db.execute(sql,params)]
if args.json:print(json.dumps(entries,ensure_ascii=False,indent=2))
else:
    for e in entries:print(f"{e['id']}\n  {e['title']}: {e['summary']}\n")
    print(f'{len(entries)} result(s)')
